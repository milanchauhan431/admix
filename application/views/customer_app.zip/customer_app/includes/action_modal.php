<div class="modal fade modalbox" id="action-modal" tabindex="-1" aria-modal="true" role="dialog" style="display: block;">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Modal title</h5>
                <a href="#" data-bs-dismiss="modal">Close</a>
            </div>
            <div class="modal-body">
                
            </div>
        </div>
    </div>
</div>
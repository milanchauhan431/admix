<?php $this->load->view('customer_app/includes/header'); ?>
<?php $this->load->view('customer_app/includes/topbar'); ?>

<div class="header header-fixed header-auto-show header-logo-app header-active">
    <a href="#" data-back-button="" class="header-title ">Back</a>
    <?php
    $param = "{'formId':'orderForm','fnsave':'confirmOrder','controller':'customerApp/dashboard'}";
    ?>
    <a href="#"  class="header-icon header-icon-2 show-on-theme-light font-19 font-700" onclick="store(<?=$param?>)"><i class="fas fa-check"></i></a>
</div>
<div class="page-content">
    <form id="orderForm"  style="margin-top:65px !important">
        <div class="error general_error text-danger ps-3"></div>
        <div class="itemForm">
            <?php
            if(!empty($fgList)){
                foreach($fgList as $row){
                    ?>
                    <div class="card card-style" > 
                        <div class="content">
                            <div class="d-flex pb-2">
                                <div class="pe-3">
                                    <h5 class="font-14 font-700 pb-2"><?=$row->item_name?></h5>
                                    <span class="d-block mb-3 mt-n3">Pcs/Box : <?=$row->packing_standard?></span>
                                </div>
                                <div class="ms-auto">
                                    <div class=" rounded-s text-center mb-1">
                                        <img src="<?= base_url() ?>assets/customer_app/images/logo.png"  class="shadow-xl" width="70">
                                    </div>
                                    <!-- <div class="mx-auto"> -->
                                        <div class="stepper rounded-s float-start">
                                            <a href="#" class="stepper-sub"><i class="fa fa-minus color-theme opacity-40"></i></a>
                                            <input type="number" min="1" max="99" value="0" name="qty[]" data-item_id ="<?=$row->id?>" >
                                            <input type="hidden" name="item_id[]" value="<?=$row->id?>">
                                            <a href="#" class="stepper-add"><i class="fa fa-plus color-theme opacity-40"></i></a>
                                        </div>
                                        <div class="clearfix"></div>
                                    <!-- </div> -->
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php
                }
            }
            ?>
        </div>
       
    </form>
       
</div>   

    
<?php $this->load->view('customer_app/includes/add_to_home'); ?>
<?php $this->load->view('customer_app/includes/footer'); ?>
<script>
function store(postData){
    console.log(postData);
    var formId = postData.formId;
    var fnsave = postData.fnsave || "save";
    var controllerName = postData.controller || controller;

    // var form = $('#orderForm')[0];
    // var fd = new FormData(form);
    var itemArray = [];
    var batchQtyArr = $("input[name='qty[]']").map(function(){
        var qty = parseFloat($(this).val());

        if(qty > 0){
            var item_id = $(this).data('item_id');
            itemArray.push({'qty':qty,'item_id':item_id});
        }
    })
    console.log(itemArray);
    if(itemArray.length === 0){
        $(".general_error").html("Select Item");
    }else{
        var url =  base_url + controller + '/confirmOrder/' + encodeURIComponent(window.btoa(JSON.stringify(itemArray)));
        window.open(url,'_self');
       
    }
    
}
  
</script>